#!/bin/sh


# LOADING TEXT TABLES:
echo "LOADING TEXT TABLES"

hive -e "LOAD DATA LOCAL INPATH '/dev/shm/Qhourly/FINAL/cnum_DL_Layer_codeword/' INTO TABLE fluxsamsunglte.cNum_DL_Layer_codeword_TEXT_FINAL";
hive -e "LOAD DATA LOCAL INPATH '/dev/shm/Qhourly/FINAL/cNum_EstabCause_QCI/' INTO TABLE fluxsamsunglte.cNum_EstabCause_QCI_TEXT_FINAL";
hive -e "LOAD DATA LOCAL INPATH '/dev/shm/Qhourly/FINAL/cNum_EstabCause/' INTO TABLE fluxsamsunglte.cNum_EstabCause_TEXT_FINAL";
hive -e "LOAD DATA LOCAL INPATH '/dev/shm/Qhourly/FINAL/cNum_QCI/' INTO TABLE fluxsamsunglte.cNum_QCI_TEXT_FINAL";
hive -e "LOAD DATA LOCAL INPATH '/dev/shm/Qhourly/FINAL/cNum_TargetEarfcnDl/' INTO TABLE fluxsamsunglte.cNum_TargetEarfcnDl_TEXT_FINAL";
hive -e "LOAD DATA LOCAL INPATH '/dev/shm/Qhourly/FINAL/cNum_tcID_HoCause/' INTO TABLE fluxsamsunglte.cNum_tcID_HoCause_TEXT_FINAL";
hive -e "LOAD DATA LOCAL INPATH '/dev/shm/Qhourly/FINAL/cNUM/' INTO TABLE fluxsamsunglte.cNum_TEXT_FINAL";

# LOADING PARQUET TABLES:
echo "LOADING PARQUET TABLES"

hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_DL_Layer_codeword_PARQUET_FINAL SELECT * FROM fluxsamsunglte.cNum_DL_Layer_codeword_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_EstabCause_QCI_PARQUET_FINAL SELECT * FROM fluxsamsunglte.cNum_EstabCause_QCI_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_EstabCause_PARQUET_FINAL SELECT * FROM fluxsamsunglte.cNum_EstabCause_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_QCI_PARQUET_FINAL SELECT * FROM fluxsamsunglte.cNum_QCI_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_TargetEarfcnDl_PARQUET_FINAL SELECT * FROM fluxsamsunglte.cNum_TargetEarfcnDl_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_tcID_HoCause_PARQUET_FINAL SELECT * FROM fluxsamsunglte.cNum_tcID_HoCause_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_PARQUET_FINAL SELECT * FROM fluxsamsunglte.cNum_TEXT_FINAL";
		
		
# LOADING ORC TABLES:
echo "LOADING ORC TABLES"

hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_DL_Layer_codeword_ORC_FINAL SELECT * FROM fluxsamsunglte.cNum_DL_Layer_codeword_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_EstabCause_QCI_ORC_FINAL SELECT * FROM fluxsamsunglte.cNum_EstabCause_QCI_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_EstabCause_ORC_FINAL SELECT * FROM fluxsamsunglte.cNum_EstabCause_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_QCI_ORC_FINAL SELECT * FROM fluxsamsunglte.cNum_QCI_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_TargetEarfcnDl_ORC_FINAL SELECT * FROM fluxsamsunglte.cNum_TargetEarfcnDl_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_tcID_HoCause_ORC_FINAL SELECT * FROM fluxsamsunglte.cNum_tcID_HoCause_TEXT_FINAL";
hive -e "INSERT OVERWRITE TABLE fluxsamsunglte.cNum_ORC_FINAL SELECT * FROM fluxsamsunglte.cNum_TEXT_FINAL";
				
		
		
		
		
