#!/bin/sh


# DROP TABLE SCRIPT:
echo "DROPPING TEXT TABLES"

hive -e "DROP TABLE fluxsamsunglte.cNum_DL_Layer_codeword_TEXT_FINAL";
hive -e "DROP TABLE fluxsamsunglte.cNum_EstabCause_QCI_TEXT_FINAL";
hive -e "DROP TABLE fluxsamsunglte.cNum_EstabCause_TEXT_FINAL";
hive -e "DROP TABLE fluxsamsunglte.cNum_QCI_TEXT_FINAL";
hive -e "DROP TABLE fluxsamsunglte.cNum_TargetEarfcnDl_TEXT_FINAL";
hive -e "DROP TABLE fluxsamsunglte.cNum_tcID_HoCause_TEXT_FINAL";
hive -e "DROP TABLE fluxsamsunglte.cNum_TEXT_FINAL";

# DROPPING PARQUET TABLES:
echo "DROPPING PARQUET TABLES"

hive -e "DROP TABLE  fluxsamsunglte.cNum_DL_Layer_codeword_PARQUET_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_EstabCause_QCI_PARQUET_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_EstabCause_PARQUET_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_QCI_PARQUET_FINAL ";
hive -e "DROP TABLE  fluxsamsunglte.cNum_TargetEarfcnDl_PARQUET_FINAL ";
hive -e "DROP TABLE  fluxsamsunglte.cNum_tcID_HoCause_PARQUET_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_PARQUET_FINAL";
		
		
# DROPPING ORC TABLES:
echo "DROPING ORC TABLES"

hive -e "DROP TABLE  fluxsamsunglte.cNum_DL_Layer_codeword_ORC_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_EstabCause_QCI_ORC_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_EstabCause_ORC_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_QCI_ORC_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_TargetEarfcnDl_ORC_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_tcID_HoCause_ORC_FINAL";
hive -e "DROP TABLE  fluxsamsunglte.cNum_ORC_FINAL";

#REMOVING EXISTING DATA
echo "DROPING TABLES DATA /user/kf416913/fluxsamsunglte_final/CNUM_FILES/EXTERNAL_TABLES/"
hadoop dfs -rmr /user/kf416913/fluxsamsunglte_final/CNUM_FILES/EXTERNAL_TABLES/*;	

#REMOVING CNUMCALC
echo "DROPING fluxsamsunglte.CNUMCALC"
hive -e "DROP TABLE  fluxsamsunglte.CNUMCALC";

#REMOVING EXISTING DATA
echo "DROPING TABLES DATA /user/kf416913/fluxsamsunglte_final/CNUM_FILES/EXTERNAL_TABLES/CNUM_END_CALC/"
hadoop dfs -rmr /user/kf416913/fluxsamsunglte_final/CNUM_FILES/EXTERNAL_TABLES/CNUM_END_CALC/*;
		
		
		
		
