#!/bin/sh
# CREATING TEXT TABLES:
echo "CREATING TEXT TABLES"
hive -f TEXT/CREATE_TABLE_cNum_DL_Layer_codeword_TEXT.hql;
hive -f TEXT/CREATE_TABLE_cNum_EstabCause_TEXT.hql;
hive -f TEXT/CREATE_TABLE_cNum_EstabCause_QCI_TEXT.hql;
hive -f TEXT/CREATE_TABLE_CNUM_TEXT.hql;
hive -f TEXT/CREATE_TABLE_cNum_QCI_TEXT.hql;
hive -f TEXT/CREATE_TABLE_cNum_TargetEarfcnDl_TEXT.hql;
hive -f TEXT/CREATE_TABLE_cNum_tcID_HoCause_TEXT.hql;



# CREATING PARQUET TABLES:
echo "CREATING PARQUET TABLES"
hive -f PARQUET/CREATE_TABLE_cNum_DL_Layer_codeword_PARQUET.hql;
hive -f PARQUET/CREATE_TABLE_cNum_EstabCause_PARQUET.hql;
hive -f PARQUET/CREATE_TABLE_cNum_EstabCause_QCI_PARQUET.hql;
hive -f PARQUET/CREATE_TABLE_CNUM_PARQUET.hql;
hive -f PARQUET/CREATE_TABLE_cNum_QCI_PARQUET.hql;
hive -f PARQUET/CREATE_TABLE_cNum_TargetEarfcnDl_PARQUET.hql;
hive -f PARQUET/CREATE_TABLE_cNum_tcID_HoCause_PARQUET.hql;



# CREATING ORC TABLES:
echo "CREATING ORC TABLES"
hive -f ORC/CREATE_TABLE_cNum_DL_Layer_codeword_ORC.hql;
hive -f ORC/CREATE_TABLE_cNum_EstabCause_ORC.hql;
hive -f ORC/CREATE_TABLE_cNum_EstabCause_QCI_ORC.hql;
hive -f ORC/CREATE_TABLE_CNUM_ORC.hql;
hive -f ORC/CREATE_TABLE_cNum_QCI_ORC.hql;
hive -f ORC/CREATE_TABLE_cNum_TargetEarfcnDl_ORC.hql;
hive -f ORC/CREATE_TABLE_cNum_tcID_HoCause_ORC.hql;

				
		
		
		
		
