package com.optum.util;

public class AvroUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	}

}
